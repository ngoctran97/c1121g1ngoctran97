create
    definer = root@localhost procedure Insert_Customer(IN first_namee varchar(255), IN last_namee varchar(255))
BEGIN
    INSERT INTO customers(first_name,last_name) VALUES (first_namee,last_namee);
END;

