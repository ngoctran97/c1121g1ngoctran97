create
    definer = root@localhost procedure update_information_produce(IN update_id int, IN update_product_code varchar(20),
                                                                  IN update_product_name varchar(45),
                                                                  IN update_product_price double,
                                                                  IN update_product_amount int,
                                                                  IN update_product_description varchar(100),
                                                                  IN update_product_status bit)
begin
update products
set product_code = update_product_code, product_name = update_product_name, product_price = update_product_price, product_amount = update_product_amount, 
product_description = update_product_description, product_status = update_product_status
where id = update_id;
end;

