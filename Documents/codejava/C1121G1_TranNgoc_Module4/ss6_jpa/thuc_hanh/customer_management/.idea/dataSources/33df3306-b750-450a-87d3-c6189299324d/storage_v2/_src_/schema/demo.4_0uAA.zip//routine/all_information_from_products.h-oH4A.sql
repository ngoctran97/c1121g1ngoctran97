create
    definer = root@localhost procedure all_information_from_products()
begin
select * from products;
end;

