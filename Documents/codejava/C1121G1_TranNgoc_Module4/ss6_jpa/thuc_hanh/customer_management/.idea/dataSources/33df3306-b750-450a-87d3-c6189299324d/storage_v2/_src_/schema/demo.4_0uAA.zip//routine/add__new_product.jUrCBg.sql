create
    definer = root@localhost procedure add__new_product(IN product_code varchar(20), IN product_name varchar(45),
                                                        IN product_price double, IN product_amount int,
                                                        IN product_description varchar(100), IN product_status bit)
begin
insert into products(product_code, product_name, product_price, product_amount, product_description, product_status)
values (product_code, product_name, product_price, product_amount, product_description, product_status);
end;

