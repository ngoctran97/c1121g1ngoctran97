create
    definer = root@localhost procedure delete_product(IN delete_id int)
begin
delete from products
where id = delete_id;
end;

